import SwiftUI

struct SettingsView: View {
    @AppStorage("reminderInterval") private var interval = 2
    @AppStorage("reminderStartHour") private var startHour = 8
    @AppStorage("reminderEndHour") private var endHour = 22
    @State private var status = ""

    var body: some View {
        Form {
            Section("Gentle reminders") {
                Picker("Every", selection: $interval) {
                    ForEach([1, 2, 3, 4, 6], id: \.self) { Text("\($0) hour\($0 == 1 ? "" : "s")").tag($0) }
                }
                Picker("Start", selection: $startHour) {
                    ForEach(0..<24, id: \.self) { Text(hourLabel($0)).tag($0) }
                }
                Picker("End", selection: $endHour) {
                    ForEach(0..<24, id: \.self) { Text(hourLabel($0)).tag($0) }
                }

                Button("Enable reminders") {
                    Task { await enableReminders() }
                }
                if !status.isEmpty { Text(status).font(.caption).foregroundStyle(MoonlitTheme.wine) }
            }

            Section("Prototype status") {
                Label("Photos stay on this iPhone", systemImage: "iphone")
                Label("Partner sync arrives in Phase 2", systemImage: "arrow.triangle.2.circlepath")
                Label("Widgets arrive after paid signing", systemImage: "square.grid.2x2")
            }

            Section("Moonlit") {
                Text("Version 0.1 local prototype")
                Text("Under the same moon, always ♡")
                    .foregroundStyle(MoonlitTheme.wine)
            }
        }
        .navigationTitle("Settings")
    }

    private func enableReminders() async {
        do {
            let granted = try await ReminderService.shared.requestPermission()
            guard granted else { status = "Notifications are not allowed in iOS Settings."; return }
            try await ReminderService.shared.schedule(.init(
                intervalHours: interval,
                startHour: startHour,
                endHour: endHour
            ))
            status = "Reminders are scheduled ♡"
        } catch {
            status = error.localizedDescription
        }
    }

    private func hourLabel(_ hour: Int) -> String {
        var components = DateComponents()
        components.hour = hour
        return Calendar.current.date(from: components)?.formatted(date: .omitted, time: .shortened) ?? "\(hour):00"
    }
}

