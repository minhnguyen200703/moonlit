# Moonlit iOS prototype

Moonlit is a private, moon-themed photo diary for two. This first implementation is a local iOS prototype that proves the visual direction and the complete capture flow before adding account pairing and cloud sync.

## Included in version 0.1

- Burgundy, cream, blush and moon-gold SwiftUI design system
- Welcome screen and three-tab app shell
- Camera capture, preview, retake and confirmation
- Optional Moon Note attached to every photo
- Local private photo persistence on the device
- Latest-moment home card, reaction button and shared-sky timeline
- Approximate current moon phase and illumination
- Configurable local reminders during active hours
- Notification taps route directly into the capture flow
- Unit test for the moon-phase calculation

This version does not yet transfer photos between iPhones. Phase 2 will add Supabase authentication, private couple pairing, encrypted transport, remote photo storage, APNs and widgets.

## What you can do on Windows

1. Edit all `.swift` files using VS Code.
2. Keep the folder in GitHub so it is easy to move between Windows and Mac.
3. Review product copy, colors, data models and backend SQL.

Native compilation, iOS Simulator testing, device signing and App Store upload require Xcode on macOS.

## First Mac setup

1. Install the latest stable Xcode supported by the Mac, then open it once and let it install components.
2. In Xcode, open **Settings > Accounts**, add your Apple Account.
3. Install XcodeGen with Homebrew:

   ```bash
   brew install xcodegen
   ```

4. In Terminal, go to this folder and generate the Xcode project:

   ```bash
   cd /path/to/Moonlit
   xcodegen generate
   open Moonlit.xcodeproj
   ```

5. Select the **Moonlit** target, open **Signing & Capabilities**, choose your Personal Team, and replace `com.minh.moonlit` with a unique bundle identifier if Xcode asks.
6. Select an iPhone simulator and press **Run**.

## Install on your own iPhone with a free Apple Account

1. Connect the iPhone to the Mac, unlock it and trust the computer.
2. Enable Developer Mode on the iPhone if iOS requests it.
3. In Xcode, select the connected iPhone as the run destination.
4. Confirm your Personal Team under **Signing & Capabilities** and press **Run**.
5. If prompted, approve the developer certificate in the iPhone's privacy/security settings.

Free signing is suited to local device testing. TestFlight and App Store distribution require enrollment in the paid Apple Developer Program.

## Test checklist

- Welcome screen appears once and opens the main app.
- Camera permission copy appears before first capture.
- Capture, Retake and Keep moment work on a real iPhone.
- Saved images remain after force-quitting and reopening the app.
- A Moon Note appears on Home and Our sky.
- Reaction state remains after restarting.
- Reminder permission is requested and reminders arrive during active hours.
- Changing the interval removes the previous Moonlit reminders and schedules the new set.

## Phase 2 build order

1. Create a Supabase project and add email or Sign in with Apple authentication.
2. Add `couples`, `couple_members`, `moments`, `reactions`, `replies` and `device_tokens` tables with row-level security.
3. Replace local-only creation with signed private uploads and realtime metadata sync.
4. Add an APNs server function for new moment, reaction and reply alerts.
5. Add an App Group and WidgetKit target for Home Screen and Lock Screen widgets.
6. Enroll in the paid Apple Developer Program, upload an archive to App Store Connect and invite Pu through TestFlight.

## Suggested repository workflow

From Windows:

```bash
git init
git add .
git commit -m "Build Moonlit local iOS prototype"
```

Push it to a private GitHub repository. On the borrowed Mac, clone the repository, run `xcodegen generate`, then build with Xcode. Do not commit API secrets, signing certificates or provisioning profiles.
