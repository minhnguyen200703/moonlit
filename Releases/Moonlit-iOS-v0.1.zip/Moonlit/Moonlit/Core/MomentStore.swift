import SwiftUI
import UIKit

@MainActor
final class MomentStore: ObservableObject {
    @Published private(set) var moments: [Moment] = []

    private let metadataURL: URL
    private let imagesDirectory: URL

    init(fileManager: FileManager = .default) {
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        imagesDirectory = documents.appendingPathComponent("MoonlitImages", isDirectory: true)
        metadataURL = documents.appendingPathComponent("moments.json")
        try? fileManager.createDirectory(at: imagesDirectory, withIntermediateDirectories: true)
        load()
    }

    var latestMoment: Moment? { moments.first }

    func add(image: UIImage, note: String) throws {
        guard let data = image.jpegData(compressionQuality: 0.82) else {
            throw MomentStoreError.imageEncodingFailed
        }
        let fileName = "\(UUID().uuidString).jpg"
        try data.write(to: imagesDirectory.appendingPathComponent(fileName), options: .atomic)
        moments.insert(Moment(note: note, imageFileName: fileName), at: 0)
        try persist()
    }

    func image(for moment: Moment) -> UIImage? {
        UIImage(contentsOfFile: imagesDirectory.appendingPathComponent(moment.imageFileName).path)
    }

    func react(to momentID: UUID, with emoji: String) {
        guard let index = moments.firstIndex(where: { $0.id == momentID }) else { return }
        moments[index].reaction = emoji
        try? persist()
    }

    private func load() {
        guard let data = try? Data(contentsOf: metadataURL),
              let saved = try? JSONDecoder().decode([Moment].self, from: data) else { return }
        moments = saved.sorted { $0.createdAt > $1.createdAt }
    }

    private func persist() throws {
        let data = try JSONEncoder().encode(moments)
        try data.write(to: metadataURL, options: .atomic)
    }
}

enum MomentStoreError: LocalizedError {
    case imageEncodingFailed

    var errorDescription: String? {
        "Moonlit could not prepare this photo. Please retake it."
    }
}

