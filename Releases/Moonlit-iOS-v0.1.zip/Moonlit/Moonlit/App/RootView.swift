import SwiftUI

struct RootView: View {
    @AppStorage("hasCompletedMoonlitWelcome") private var hasCompletedWelcome = false
    @State private var openCameraRequest = false

    var body: some View {
        Group {
            if hasCompletedWelcome {
                MainTabView(openCameraRequest: $openCameraRequest)
            } else {
                WelcomeView {
                    withAnimation(.easeInOut(duration: 0.35)) {
                        hasCompletedWelcome = true
                    }
                }
            }
        }
        .tint(MoonlitTheme.burgundy)
        .onReceive(NotificationCenter.default.publisher(for: .openMoonlitCamera)) { _ in
            if hasCompletedWelcome { openCameraRequest = true }
        }
    }
}

private struct WelcomeView: View {
    let continueAction: () -> Void

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [MoonlitTheme.burgundy, MoonlitTheme.wine],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 24) {
                Spacer()
                MoonMark(size: 132)

                VStack(spacing: 8) {
                    Text("moonlit")
                        .font(.system(size: 48, weight: .semibold, design: .serif))
                        .foregroundStyle(MoonlitTheme.cream)
                    Text("under the same moon, always ♡")
                        .font(.callout)
                        .foregroundStyle(MoonlitTheme.blush)
                }

                Text("A tiny private place for two people to share the ordinary moments that make a day feel close.")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(MoonlitTheme.cream.opacity(0.9))
                    .padding(.horizontal, 34)

                Spacer()

                Button(action: continueAction) {
                    Text("Enter our little universe")
                        .fontWeight(.semibold)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(MoonlitTheme.cream, in: Capsule())
                        .foregroundStyle(MoonlitTheme.burgundy)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 28)
            }
        }
    }
}

private struct MainTabView: View {
    @Binding var openCameraRequest: Bool

    var body: some View {
        TabView {
            NavigationStack { HomeView(openCameraRequest: $openCameraRequest) }
                .tabItem { Label("Us", systemImage: "moon.stars.fill") }

            NavigationStack { TimelineView() }
                .tabItem { Label("Our sky", systemImage: "sparkles") }

            NavigationStack { SettingsView() }
                .tabItem { Label("Settings", systemImage: "slider.horizontal.3") }
        }
    }
}
