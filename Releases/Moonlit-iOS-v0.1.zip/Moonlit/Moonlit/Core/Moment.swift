import Foundation

struct Moment: Identifiable, Codable, Equatable {
    let id: UUID
    let createdAt: Date
    let senderName: String
    let note: String
    let imageFileName: String
    var reaction: String?

    init(
        id: UUID = UUID(),
        createdAt: Date = .now,
        senderName: String = "Me",
        note: String,
        imageFileName: String,
        reaction: String? = nil
    ) {
        self.id = id
        self.createdAt = createdAt
        self.senderName = senderName
        self.note = note
        self.imageFileName = imageFileName
        self.reaction = reaction
    }
}

